# Part 1 — Models & Relationships

> How Django turns Python classes into database tables, and how relationships actually work at the SQL level.

---

## What Is a Model, Really?

A Django model is a Python class that maps to one database table. Each instance of the class is one row. Each class attribute that's a `Field` becomes a column. Django's ORM generates the SQL to create, query, update, and delete rows — you write Python, it writes SQL.

```python
from django.db import models

class Customer(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField(unique=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "customers"
        ordering = ["-created_at"]

    def __str__(self):
        return self.name
```

When you run `python manage.py makemigrations` and then `migrate`, Django creates this in your database:

```sql
CREATE TABLE customers (
    id         BIGINT PRIMARY KEY AUTO_INCREMENT,
    name       VARCHAR(200) NOT NULL,
    email      VARCHAR(254) NOT NULL UNIQUE,
    is_active  BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
);
```

Notice: you never defined `id`. Since Django 3.2, every model gets a `BigAutoField` as primary key automatically. You can override this if you want UUIDs or something else:

```python
import uuid

class Customer(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    # ... rest of fields
```

The `auto_now_add=True` and `auto_now=True` distinction matters: `auto_now_add` stamps the datetime only when the row is first INSERT-ed and never changes. `auto_now` updates the timestamp on every `.save()` call. Neither shows up in forms or admin by default because Django sets `editable=False` on them internally.

---

## Field Types — What You'll Actually Use

### Text Fields

```python
models.CharField(max_length=255)      # VARCHAR — you MUST specify max_length
models.TextField()                     # TEXT — unlimited length, no max_length needed
models.SlugField(max_length=100)       # VARCHAR + automatic db_index (for URL slugs like "my-blog-post")
models.EmailField()                    # just a CharField with email validation baked in
models.URLField()                      # CharField with URL validation
```

`CharField` vs `TextField` — use `CharField` when you know the maximum (names, titles, codes). Use `TextField` for things like descriptions, bios, long notes. In PostgreSQL both are stored the same way internally, but in MySQL the distinction matters for indexing.

### Numbers

```python
models.IntegerField()                  # -2B to +2B
models.BigIntegerField()               # for very large numbers
models.PositiveIntegerField()          # 0 and above — adds a CHECK constraint
models.DecimalField(max_digits=10, decimal_places=2)   # exact precision — USE THIS FOR MONEY
models.FloatField()                    # IEEE 754 floating point — fast but approximate
```

Why `DecimalField` for money? Because `0.1 + 0.2 = 0.30000000000000004` in floating point. `Decimal("0.1") + Decimal("0.2") = Decimal("0.3")` — exact. Financial calculations need exact math. `max_digits` is the total number of digits (before + after the decimal point), `decimal_places` is how many after the dot. So `max_digits=10, decimal_places=2` stores up to `99999999.99`.

### Dates and Times

```python
models.DateField()                     # just the date (2024-06-15)
models.DateTimeField()                 # date + time (2024-06-15 14:30:00)
models.TimeField()                     # just the time (14:30:00)
models.DurationField()                 # stores a Python timedelta
```

### Boolean, JSON, UUID

```python
models.BooleanField(default=False)     # True/False — always set a default
models.JSONField(default=dict)         # native JSON column (Postgres, MySQL 5.7+, SQLite 3.9+)
models.UUIDField(default=uuid.uuid4)   # 128-bit universally unique identifier
```

`JSONField` is powerful — you can query inside it with lookups like `data__key__contains="value"`. But don't use it as a replacement for proper relational modeling. It's best for truly unstructured or variable data.

### Files

```python
models.FileField(upload_to="documents/%Y/%m/")    # stores file path as a string
models.ImageField(upload_to="photos/")              # same as FileField + validates it's an image
```

The `upload_to` can be a string with strftime formatting, or a callable that receives the instance and filename. The actual file goes to your `MEDIA_ROOT`; the DB column stores just the relative path string.

---

## Common Field Options

Every field type accepts these keyword arguments:

```python
models.CharField(
    max_length=100,

    # --- Database level ---
    null=True,            # column allows NULL in the DB
    db_index=True,        # creates a B-tree index on this column
    unique=True,          # UNIQUE constraint — no two rows can have the same value
    db_column="col_name", # override the actual column name (default: the Python attribute name)
    db_comment="...",     # SQL comment on the column (Django 4.2+)

    # --- Application/validation level ---
    blank=True,           # allows empty string in forms and serializers
    default="unknown",    # default value if none provided
    choices=[             # restricts allowed values + provides display labels
        ("A", "Active"),
        ("I", "Inactive"),
        ("S", "Suspended"),
    ],
    validators=[...],     # list of validation functions
    help_text="...",      # documentation for forms and admin
    editable=False,       # excluded from forms entirely

    # --- Display ---
    verbose_name="customer name",  # human-readable name (default: attribute name with underscores → spaces)
)
```

### The `null` vs `blank` Confusion

These control two completely different things:

- **`null=True`** is a **database** concern: the column accepts NULL.
- **`blank=True`** is a **validation** concern: forms and serializers accept empty input.

For **string fields** (CharField, TextField), Django convention is: don't use `null=True`. Use `blank=True, default=""` instead. Why? Because with `null=True` you'd have two ways to represent "no data" — an empty string `""` and a `NULL`. That creates confusion when querying (`WHERE name = ''` vs `WHERE name IS NULL`). One representation is better.

For **non-string fields** (DateField, ForeignKey, IntegerField), use `null=True, blank=True` together when the field is optional. These types don't have an "empty string" concept, so NULL is the only way to say "no value."

```python
# String — optional
bio = models.TextField(blank=True, default="")        # ✅ Django convention
bio = models.TextField(null=True, blank=True)          # ❌ works but now you have "" AND NULL

# Date — optional
birth_date = models.DateField(null=True, blank=True)   # ✅ correct
birth_date = models.DateField(blank=True)              # ❌ no NULL, but no default either — will crash on save
```

### The `choices` Field

```python
class Order(models.Model):
    class Status(models.TextChoices):       # Django 3.0+ — cleaner than raw tuples
        PENDING = "pending", "Pending"
        CONFIRMED = "confirmed", "Confirmed"
        SHIPPED = "shipped", "Shipped"
        CANCELLED = "cancelled", "Cancelled"

    status = models.CharField(
        max_length=20,
        choices=Status.choices,             # generates the tuple list automatically
        default=Status.PENDING,
    )

# Usage:
order = Order.objects.get(id=1)
order.status                    # → "pending" (the raw DB value)
order.get_status_display()      # → "Pending" (the human-readable label)
order.status == Order.Status.PENDING   # → True (compare against the enum)

# Filtering:
Order.objects.filter(status=Order.Status.CONFIRMED)
```

`IntegerChoices` works the same way for integer fields. This enum pattern is much better than hardcoding string literals everywhere.

---

## Relationships — The Heart of Relational Databases

### ForeignKey — "Many-to-One"

This is the most common relationship. "Many orders belong to one customer." The FK column lives on the "many" side.

```python
class Customer(models.Model):
    name = models.CharField(max_length=200)

class Order(models.Model):
    customer = models.ForeignKey(
        Customer,
        on_delete=models.CASCADE,
        related_name="orders",
    )
    total = models.DecimalField(max_digits=10, decimal_places=2)
```

**What the DB actually stores:**

Order doesn't get a `customer` column — it gets a `customer_id` column (an integer FK). Django automatically appends `_id` to the column name. You can access both:

```python
order.customer       # follows the FK, returns a Customer object (may hit DB if not loaded)
order.customer_id    # just the integer value — NO database hit, it's already on the row
```

This distinction matters for performance. If you only need the ID (e.g., to pass to a serializer), use `order.customer_id` — it avoids a query.

**Forward vs Reverse access:**

```python
# FORWARD access: Order → Customer
# You're following the FK column that physically exists on Order.
order.customer              # returns a single Customer instance

# REVERSE access: Customer → Orders
# There is NO column on the Customer table pointing to orders.
# Django manufactures this accessor from the related_name.
customer.orders             # this is a RelatedManager, not a queryset yet
customer.orders.all()       # NOW it's a queryset — "all orders for this customer"
customer.orders.filter(total__gt=100)
customer.orders.count()
customer.orders.exists()
customer.orders.create(total=50.00)    # creates an Order with customer already set
```

Without `related_name`, Django auto-generates `customer.order_set`. That's ugly. Always set `related_name`. If you want to disable reverse access entirely (rare), set `related_name="+"`.

**`on_delete` — what happens when the referenced object is deleted:**

This is required and there's no "right" default — it depends on your domain:

```python
on_delete=models.CASCADE       # delete the order too (most common for child records)
on_delete=models.PROTECT       # block deletion entirely — raise ProtectedError
on_delete=models.SET_NULL      # set customer_id to NULL (field MUST have null=True)
on_delete=models.SET_DEFAULT   # set to the field's default value
on_delete=models.RESTRICT      # like PROTECT, but allows deletion if the related object
                                # is being deleted in the same operation (e.g., cascading from elsewhere)
on_delete=models.DO_NOTHING    # hands-off — you're responsible for DB integrity yourself
```

Think about it this way: if a Customer is deleted, what should happen to their Orders? If orders make no sense without a customer → `CASCADE`. If deleting a customer who still has orders is a mistake → `PROTECT`. If orders should survive but just lose the customer reference → `SET_NULL`.


### OneToOneField — "Exactly One on Each Side"

Used when one record maps to exactly one record in another table. The classic example is extending a model with a profile.

```python
class Customer(models.Model):
    name = models.CharField(max_length=200)

class CustomerProfile(models.Model):
    customer = models.OneToOneField(
        Customer,
        on_delete=models.CASCADE,
        related_name="profile",
    )
    bio = models.TextField(blank=True, default="")
    avatar_url = models.URLField(blank=True, default="")
```

Under the hood, `OneToOneField` is literally `ForeignKey(..., unique=True)`. The DB column is identical. The difference is how Django exposes it in Python:

```python
# Forward — same as FK
profile.customer          # → Customer instance

# Reverse — THIS is where it differs from FK
customer.profile          # → CustomerProfile instance (single object, not a manager!)
customer.profile.bio      # direct attribute access

# Compare with FK reverse:
customer.orders           # → RelatedManager — you need .all(), .filter(), etc.
customer.profile          # → the object directly — no .all() needed
```

If the profile doesn't exist, `customer.profile` raises `RelatedObjectDoesNotExist` (a subclass of `DoesNotExist`). Handle it:

```python
try:
    bio = customer.profile.bio
except CustomerProfile.DoesNotExist:
    bio = ""

# Or use hasattr:
if hasattr(customer, "profile"):
    bio = customer.profile.bio
```


### ManyToManyField — and What a Join Table Actually Is

"A product can have many tags. A tag can be on many products." Neither side can store this in a single column — you need a third table.

```python
class Tag(models.Model):
    name = models.CharField(max_length=50, unique=True)

class Product(models.Model):
    name = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    tags = models.ManyToManyField(Tag, related_name="products", blank=True)
```

**The join table Django creates automatically:**

```sql
CREATE TABLE appname_product_tags (
    id          BIGINT PRIMARY KEY AUTO_INCREMENT,
    product_id  BIGINT NOT NULL REFERENCES products(id),
    tag_id      BIGINT NOT NULL REFERENCES tags(id),
    UNIQUE (product_id, tag_id)     -- prevents the same pair from appearing twice
);
```

This table has exactly two FK columns — one pointing to each side of the relationship. Nothing else. Django manages it completely behind the scenes.

**Why a join table?** Think about it: Product #1 has tags "electronics" and "sale". Product #2 has tag "electronics". You can't store a list of tag IDs in a single column in a relational DB (well, you *can* with JSON, but then you lose referential integrity, indexing, and joins). The join table stores one row per (product, tag) pair:

```
product_id | tag_id
-----------+-------
    1      |   1       ← Product 1 has Tag "electronics"
    1      |   2       ← Product 1 has Tag "sale"
    2      |   1       ← Product 2 has Tag "electronics"
```

**Working with M2M relationships:**

```python
product = Product.objects.get(id=1)
tag_electronics = Tag.objects.get(name="electronics")
tag_sale = Tag.objects.get(name="sale")

# Add tags (inserts rows into the join table)
product.tags.add(tag_electronics, tag_sale)

# Remove a tag (deletes the row from the join table)
product.tags.remove(tag_sale)

# Replace all tags (clears existing, adds new)
product.tags.set([tag_electronics])

# Clear all tags
product.tags.clear()

# Query
product.tags.all()                      # all tags for this product
product.tags.filter(name__startswith="e")

# Reverse
tag_electronics.products.all()          # all products with this tag
tag_electronics.products.count()
```

**Where you define the field matters for code organization, not the DB.** The join table is the same regardless of which model has the `ManyToManyField`. Put it on whichever side makes more conceptual sense ("a product *has* tags" reads better than "a tag *has* products").


### Custom Join Table with `through` — When the Relationship Itself Has Data

Sometimes the join table needs extra columns. A student enrolls in a course — and you want to know *when* they enrolled and what *grade* they got. That data belongs to the *relationship*, not to either the student or the course.

```python
class Student(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()

class Course(models.Model):
    title = models.CharField(max_length=200)
    students = models.ManyToManyField(
        Student,
        through="Enrollment",          # ← "use this model as the join table"
        related_name="courses",
    )

class Enrollment(models.Model):
    """This IS the join table — but now you control it."""
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="enrollments")
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="enrollments")
    enrolled_on = models.DateField(auto_now_add=True)
    grade = models.CharField(max_length=2, blank=True, default="")
    is_auditing = models.BooleanField(default=False)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["student", "course"], name="unique_enrollment"),
        ]

    def __str__(self):
        return f"{self.student.name} → {self.course.title}"
```

The join table in the DB now looks like:

```sql
CREATE TABLE appname_enrollment (
    id           BIGINT PRIMARY KEY,
    student_id   BIGINT NOT NULL REFERENCES students(id),
    course_id    BIGINT NOT NULL REFERENCES courses(id),
    enrolled_on  DATE NOT NULL,
    grade        VARCHAR(2) NOT NULL DEFAULT '',
    is_auditing  BOOLEAN NOT NULL DEFAULT FALSE,
    UNIQUE (student_id, course_id)
);
```

Still has the two FK columns (that's what makes it a join table), but now you can hang extra data on each relationship row.

**Important behavior change:** With a `through` model, Django restricts the M2M shortcut methods:

```python
# These NO LONGER WORK with a through model:
course.students.add(student)        # ❌ — Django doesn't know what to set for grade, enrolled_on, etc.
course.students.create(name="Bob")  # ❌ — same problem

# You MUST create the intermediary object directly:
Enrollment.objects.create(student=student, course=course, grade="B+")

# These still work:
course.students.remove(student)     # ✅ — just deletes the Enrollment row
course.students.clear()             # ✅ — deletes all Enrollment rows for this course

# The M2M traversal still works normally:
course.students.all()               # ✅ — returns Student instances
student.courses.all()               # ✅ — returns Course instances

# And you can query the intermediary model directly:
Enrollment.objects.filter(course=course, grade__in=["A", "A+"])
```


### Using an Existing DB Table as a Join Table

If you have a legacy database with a table that already serves as a join table, you can wrap it with a Django model without Django trying to create or modify it:

```python
class LegacyProductCategory(models.Model):
    """Wraps an existing join table that someone created years ago."""
    product = models.ForeignKey("Product", on_delete=models.DO_NOTHING, db_column="prod_id")
    category = models.ForeignKey("Category", on_delete=models.DO_NOTHING, db_column="cat_id")
    added_by = models.CharField(max_length=50)  # extra column that's already in the table

    class Meta:
        managed = False                          # Django will NOT create/alter/delete this table
        db_table = "legacy_product_categories"   # point to the existing table name

# Now use it as a through model:
class Product(models.Model):
    categories = models.ManyToManyField(
        "Category",
        through=LegacyProductCategory,
        related_name="products",
    )
```

`managed = False` tells Django: "this table already exists, don't touch it during migrations." Django doesn't care who created the table — it just needs the FK columns to be there.

---

## Model Constraints and Indexes

Django gives you database-level constraints that enforce rules the application can't accidentally break.

### UniqueConstraint

```python
class Meta:
    constraints = [
        # Simple: no two enrollments with the same student+course
        models.UniqueConstraint(
            fields=["student", "course"],
            name="unique_student_course",
        ),

        # Conditional unique: only enforce for active enrollments
        # This uses a partial index — only rows matching the condition are checked
        models.UniqueConstraint(
            fields=["student", "course"],
            condition=models.Q(is_active=True),
            name="unique_active_enrollment",
        ),
    ]
```

The conditional version is powerful. Without it, a soft-deleted enrollment would block a student from re-enrolling in the same course. With `condition=Q(is_active=True)`, only active enrollments are checked.

### CheckConstraint

```python
class Meta:
    constraints = [
        # Price must be positive
        models.CheckConstraint(
            check=models.Q(price__gt=0),
            name="positive_price",
        ),

        # Start date must be before end date
        models.CheckConstraint(
            check=models.Q(start_date__lt=models.F("end_date")),
            name="start_before_end",
        ),

        # Grade must be valid
        models.CheckConstraint(
            check=models.Q(grade__in=["A", "B", "C", "D", "F", ""]),
            name="valid_grade",
        ),
    ]
```

These create `CHECK` constraints in the database. If any INSERT or UPDATE violates them, the DB raises an error and Django translates it to `IntegrityError`. This is your safety net below the application layer.

### Indexes

```python
class Meta:
    indexes = [
        # Single column index — speeds up WHERE and ORDER BY on this column
        models.Index(fields=["created_at"]),

        # Composite index — speeds up queries that filter/sort on BOTH columns together
        models.Index(fields=["customer", "created_at"]),

        # Descending index — useful if you always ORDER BY created_at DESC
        models.Index(fields=["-created_at"], name="recent_orders_idx"),

        # Partial index — only indexes rows matching the condition
        # Much smaller than a full index, faster for the queries that need it
        models.Index(
            fields=["status"],
            condition=models.Q(status="pending"),
            name="pending_orders_idx",
        ),
    ]
```

Index order matters for composite indexes. An index on `["customer", "created_at"]` helps queries that filter by customer, or by customer + created_at, but does NOT help queries that filter only by created_at. Think of it like a phone book: sorted by last name then first name — you can look up "Smith" fast, or "Smith, John" fast, but not "John" across all last names.

---

## `class Meta` Reference

```python
class Meta:
    # --- Table ---
    db_table = "custom_table_name"           # override auto-generated table name
    managed = False                          # True = Django manages migrations. False = hands off.

    # --- Ordering ---
    ordering = ["-created_at", "name"]       # default ORDER BY for all querysets on this model
    get_latest_by = "created_at"             # enables .latest() and .earliest()

    # --- Display ---
    verbose_name = "order"
    verbose_name_plural = "orders"

    # --- Constraints & Indexes ---
    constraints = [...]
    indexes = [...]

    # --- Inheritance ---
    abstract = True                          # no table created — only for subclassing

    # --- Legacy (still work, prefer constraints/indexes above) ---
    unique_together = [("field1", "field2")]
    index_together = [("field1", "field2")]
```

When `abstract = True`, Django doesn't create a table for this model. It's purely a base class — its fields get copied into any model that inherits from it. Useful for shared fields like `created_at`, `updated_at`, `is_deleted`.

```python
class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True      # no "timestampedmodel" table will be created

class Order(TimeStampedModel):       # gets created_at and updated_at automatically
    total = models.DecimalField(max_digits=10, decimal_places=2)

class Invoice(TimeStampedModel):     # same — gets the timestamp fields
    amount = models.DecimalField(max_digits=10, decimal_places=2)
```

---

*Next: [Part 2 — QuerySets & Query Building](./02_querysets_and_query_building.md) — how to actually ask your database questions.*
