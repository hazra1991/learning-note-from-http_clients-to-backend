# Part 2 — QuerySets & Query Building

> How Django translates your Python calls into SQL, and how to compose complex queries without writing SQL yourself.

---

## What Is a QuerySet?

A QuerySet is a **lazy representation of a database query**. When you write `Order.objects.filter(status="active")`, Django doesn't touch the database. It builds an internal SQL description and waits. The query only fires when you actually need the data — iteration, indexing, slicing, or calling a terminal method.

This laziness is the single most important thing to understand about the ORM. It's what makes chaining possible.

```python
# None of these lines hit the database:
qs = Order.objects.all()
qs = qs.filter(status="active")
qs = qs.filter(total__gt=100)
qs = qs.order_by("-created_at")
qs = qs.select_related("customer")

# The DB is hit HERE — when you consume the queryset:
orders = list(qs)           # iteration → fires the query
first = qs[0]               # indexing → fires with LIMIT 1
page = qs[5:15]             # slicing an unevaluated qs → fires with LIMIT 10 OFFSET 5
for order in qs:            # iteration
    print(order)
```

**Why this matters:** You can build a queryset in pieces across your code — add filters in a view, add ordering in a serializer, add select_related in a mixin — and the query only fires once at the end. One query, not five.

### QuerySet Evaluation and Caching

Once a queryset is evaluated (the query fires), the results are cached inside the queryset object in `_result_cache`. Subsequent iterations of the **same queryset variable** use the cache:

```python
qs = Order.objects.filter(status="active")

# First iteration — hits the DB, caches results in qs._result_cache
for order in qs:
    print(order.id)

# Second iteration of the SAME variable — uses cache, no DB hit
for order in qs:
    print(order.total)

# BUT — calling .filter() creates a NEW queryset with an empty cache
qs2 = qs.filter(total__gt=100)    # new queryset — will hit DB when evaluated
```

This is different from the prefetch cache (covered in Part 3). This is the queryset's own internal result cache.

---

## Chainable Methods — Building Queries Piece by Piece

Each of these returns a **new** QuerySet (the original is unchanged — querysets are immutable):

### Filtering and Excluding

```python
# filter — rows that MATCH the condition (WHERE ...)
Order.objects.filter(status="active")

# exclude — rows that DON'T match (WHERE NOT ...)
Order.objects.exclude(status="cancelled")

# Chaining filter = AND
Order.objects.filter(status="active").filter(total__gt=100)
# → WHERE status = 'active' AND total > 100

# Multiple kwargs in one filter = also AND
Order.objects.filter(status="active", total__gt=100)
# → same SQL as above
```

### Ordering

```python
Order.objects.order_by("created_at")          # ASC
Order.objects.order_by("-created_at")         # DESC (the minus prefix)
Order.objects.order_by("-created_at", "id")   # DESC by created_at, then ASC by id (tiebreaker)
Order.objects.order_by()                      # clears any default ordering from Meta
```

If your model has `ordering = ["-created_at"]` in Meta, that applies to every queryset unless you explicitly call `.order_by()` to override or clear it. Clearing is important for `.distinct()` — Postgres requires that ORDER BY columns be in SELECT for DISTINCT queries.

### Limiting Columns

```python
# values — returns dicts instead of model instances
Order.objects.values("id", "total", "customer__name")
# → [{"id": 1, "total": Decimal("50.00"), "customer__name": "Alice"}, ...]
# The SQL uses SELECT id, total + JOIN for customer__name

# values_list — returns tuples
Order.objects.values_list("id", "total")
# → [(1, Decimal("50.00")), (2, Decimal("120.00")), ...]

# values_list with flat=True — returns a flat list (only works with one field)
Order.objects.values_list("id", flat=True)
# → [1, 2, 3, 4, ...]

# only — returns model instances, but only loads these columns
Order.objects.only("id", "total")
# Accessing order.status on the result would trigger a SECOND query to fetch it (deferred field)

# defer — opposite of only: load everything EXCEPT these
Order.objects.defer("large_text_field")
```

`values()` and `values_list()` are useful when you don't need full model instances — they're faster because Django skips constructing Python objects. `only()` and `defer()` give you model instances but with deferred loading — accessing a deferred field triggers an individual query per instance, so be careful.

### Other Chainable Methods

```python
qs.distinct()               # SELECT DISTINCT — deduplicates rows
qs.reverse()                # flip the ordering (requires ordering to be set)
qs.none()                   # returns empty queryset — useful as a safe "default"
qs[:10]                     # LIMIT 10 (slicing an unevaluated qs)
qs[5:10]                    # OFFSET 5 LIMIT 5
```

---

## Terminal Methods — Executing the Query

These trigger the query immediately and return a result (not a queryset):

```python
# --- Single objects ---
qs.get(id=1)                # returns exactly one object. Raises DoesNotExist if 0 found,
                             # MultipleObjectsReturned if 2+ found.
qs.first()                  # first object or None (adds LIMIT 1)
qs.last()                   # last object or None (reverses ordering + LIMIT 1)
qs.earliest("created_at")   # earliest by that field
qs.latest("created_at")     # latest by that field

# --- Existence and counting ---
qs.exists()                 # True/False — SELECT 1 ... LIMIT 1 (very efficient)
qs.count()                  # SELECT COUNT(*) (don't use len(qs) — that fetches all rows first)

# --- Creating ---
qs.create(customer=c, total=100)          # INSERT → returns the new object
qs.get_or_create(email="a@b.com", defaults={"name": "Alice"})
    # → (object, created_bool) — tries GET, does CREATE if not found
qs.update_or_create(email="a@b.com", defaults={"name": "Alice"})
    # → (object, created_bool) — tries GET + UPDATE, does CREATE if not found

# --- Bulk operations ---
qs.bulk_create([Order(total=50), Order(total=100)], batch_size=500)
qs.bulk_update(objects, ["status", "total"], batch_size=500)

# --- Updating (no .save(), no signals) ---
qs.update(status="cancelled")    # UPDATE ... SET status='cancelled' WHERE ...
    # Returns the number of rows affected. Does NOT call .save() on each instance,
    # does NOT trigger pre_save/post_save signals.

# --- Deleting ---
qs.delete()    # DELETE FROM ... WHERE ...
    # Returns (count, {"app.Model": count}). Triggers pre_delete/post_delete by default.

# --- Aggregation ---
qs.aggregate(total=Sum("total"))   # → {"total": Decimal("5230.00")}
```

### `get()` vs `first()` — When to Use Which

```python
# Use get() when you EXPECT exactly one result and it's a bug if there isn't one:
user = User.objects.get(id=request.user.id)      # should always exist

# Use first() when zero results is a normal case:
latest = Order.objects.filter(customer=c).order_by("-created_at").first()
if latest is None:
    # no orders yet — handle it
```

---

## Field Lookups — The Double-Underscore Magic

The `__` syntax is how Django expresses SQL operators inside `.filter()`, `.exclude()`, and `.get()`. The pattern is `field__lookup=value`.

### Comparison

```python
filter(age=25)              # WHERE age = 25 (same as age__exact=25)
filter(age__gt=25)          # WHERE age > 25
filter(age__gte=25)         # WHERE age >= 25
filter(age__lt=25)          # WHERE age < 25
filter(age__lte=25)         # WHERE age <= 25
```

### Membership

```python
filter(status__in=["active", "pending"])
# → WHERE status IN ('active', 'pending')

# You can pass a queryset — Django turns it into a subquery:
active_customer_ids = Customer.objects.filter(is_active=True).values_list("id", flat=True)
Order.objects.filter(customer_id__in=active_customer_ids)
# → WHERE customer_id IN (SELECT id FROM customers WHERE is_active = TRUE)
```

### Text Matching

```python
filter(name__contains="django")       # WHERE name LIKE '%django%' (case-sensitive)
filter(name__icontains="django")      # WHERE name ILIKE '%django%' (case-insensitive)
filter(name__startswith="Dj")         # WHERE name LIKE 'Dj%'
filter(name__istartswith="dj")        # case-insensitive
filter(name__endswith="go")           # WHERE name LIKE '%go'
filter(name__regex=r"^[A-Z]")         # WHERE name ~ '^[A-Z]' (Postgres regex)
filter(name__iregex=r"^[a-z]")        # case-insensitive regex
```

### Null and Boolean

```python
filter(email__isnull=True)            # WHERE email IS NULL
filter(email__isnull=False)           # WHERE email IS NOT NULL
```

### Dates and Times

```python
filter(created_at__year=2024)                         # EXTRACT(YEAR FROM created_at) = 2024
filter(created_at__month=6)
filter(created_at__day=15)
filter(created_at__week_day=2)                        # Monday = 2 in Django
filter(created_at__date=date(2024, 6, 15))            # just the date part of a datetime
filter(created_at__range=(start_date, end_date))      # BETWEEN
```

### Traversing Relationships with `__`

This is where the double-underscore syntax really shines. You can follow relationships across tables, and Django generates the JOINs for you:

```python
# Forward FK traversal: Order has FK to Customer
Order.objects.filter(customer__name="Alice")
# → SELECT * FROM orders
#   INNER JOIN customers ON orders.customer_id = customers.id
#   WHERE customers.name = 'Alice'

# Multi-hop: Customer → Profile (OneToOne)
Order.objects.filter(customer__profile__bio__icontains="engineer")
# → SELECT * FROM orders
#   INNER JOIN customers ON orders.customer_id = customers.id
#   INNER JOIN customer_profiles ON customers.id = customer_profiles.customer_id
#   WHERE customer_profiles.bio ILIKE '%engineer%'

# Reverse FK traversal: Customer ← Orders
Customer.objects.filter(orders__total__gt=1000)
# → SELECT DISTINCT * FROM customers
#   INNER JOIN orders ON customers.id = orders.customer_id
#   WHERE orders.total > 1000
# Note the DISTINCT — without it, a customer with multiple matching orders appears multiple times

# M2M traversal: Product ← join table → Tags
Product.objects.filter(tags__name="electronics")
# → SELECT * FROM products
#   INNER JOIN product_tags ON products.id = product_tags.product_id
#   INNER JOIN tags ON product_tags.tag_id = tags.id
#   WHERE tags.name = 'electronics'
```

Every `__` step across a relationship generates a JOIN. Django handles the join conditions automatically based on the FK columns it knows about.

---

## Q Objects — OR, NOT, and Complex Logic

By default, multiple `.filter()` conditions are AND-ed. But what about OR? That's where `Q` comes in.

```python
from django.db.models import Q
```

### The Problem Q Solves

```python
# How do you write: "orders that are either high-value OR marked priority"?

# This won't work — chained filters are AND:
Order.objects.filter(total__gt=500).filter(status="priority")
# → WHERE total > 500 AND status = 'priority'    ← not what we want

# Q objects let you express OR:
Order.objects.filter(Q(total__gt=500) | Q(status="priority"))
# → WHERE total > 500 OR status = 'priority'      ← correct
```

### The Operators

```python
# OR — the pipe character
Q(total__gt=500) | Q(status="priority")
# → (total > 500 OR status = 'priority')

# AND — the ampersand
Q(total__gt=500) & Q(status="active")
# → (total > 500 AND status = 'active')
# (Same as chaining .filter(), but needed inside OR expressions)

# NOT — the tilde
~Q(status="cancelled")
# → NOT (status = 'cancelled')
```

### Why Q Is Not Just "Another Way to Filter"

Q objects are **composable** — you can build them up programmatically:

```python
# Build a dynamic query from user-selected filters
conditions = Q()   # starts as "nothing" — matches everything when AND-ed

if user_wants_active:
    conditions &= Q(status="active")

if user_wants_recent:
    conditions &= Q(created_at__gte=last_week)

if user_selected_categories:
    conditions &= Q(category__in=user_selected_categories)

results = Product.objects.filter(conditions)
```

This is something you simply cannot do by chaining `.filter()` calls when you need OR logic or dynamic composition.

### Complex Nesting

Q objects nest like Boolean algebra:

```python
# (high value OR priority) AND NOT cancelled AND customer is active
Order.objects.filter(
    (Q(total__gt=500) | Q(status="priority"))
    & ~Q(status="cancelled")
    & Q(customer__is_active=True)
)
# → WHERE (total > 500 OR status = 'priority')
#     AND NOT (status = 'cancelled')
#     AND customers.is_active = TRUE
```

### Gotcha: Mixing Q and kwargs

When mixing Q objects with keyword arguments in `.filter()`, Q objects **must come first**:

```python
# ✅ Correct — Q first, then kwargs
Order.objects.filter(Q(total__gt=500) | Q(status="priority"), customer=c)

# ❌ SyntaxError — kwargs before Q
Order.objects.filter(customer=c, Q(total__gt=500) | Q(status="priority"))
```

---

## F Expressions — Referencing Column Values

`F()` lets you reference the value of a model field inside a query, so the database does the comparison or arithmetic — not Python.

```python
from django.db.models import F
```

### The Problem F Solves

```python
# "Find products where stock is below the reorder level"

# Without F — you'd have to load every product into Python:
for product in Product.objects.all():     # fetches ALL products
    if product.stock < product.reorder_level:
        low_stock.append(product)
# Terrible — loads entire table into memory.

# With F — the database does the comparison:
Product.objects.filter(stock__lt=F("reorder_level"))
# → SELECT * FROM products WHERE stock < reorder_level
# Fast, memory-efficient, one query.
```

The key insight: `F("reorder_level")` doesn't fetch the value — it tells Django to reference that **column** in the SQL. The comparison happens inside the database engine, row by row.

### F in Updates — Avoiding Race Conditions

This is one of the most practically important uses:

```python
# BAD — race condition:
product = Product.objects.get(id=1)
product.stock = product.stock - 1    # reads stock into Python
product.save()                       # writes it back
# If two requests read stock=10 simultaneously, both write 9. You lost a decrement.

# GOOD — atomic database operation:
Product.objects.filter(id=1).update(stock=F("stock") - 1)
# → UPDATE products SET stock = stock - 1 WHERE id = 1
# The database handles the read-modify-write atomically. No race condition.
```

### F in Arithmetic and Annotations

```python
# Compute profit margin per product (in the database)
Product.objects.annotate(
    profit=F("price") - F("cost"),
    margin_pct=(F("price") - F("cost")) * 100.0 / F("price"),
)

# Compare dates — "orders that shipped more than 7 days after creation"
from datetime import timedelta
Order.objects.filter(
    shipped_at__gt=F("created_at") + timedelta(days=7)
)
# → WHERE shipped_at > created_at + INTERVAL '7 days'
```

### F Across Relationships

You can follow ForeignKey relationships in F expressions:

```python
# "Orders where the total exceeds the customer's credit limit"
Order.objects.filter(total__gt=F("customer__credit_limit"))
# → SELECT * FROM orders
#   INNER JOIN customers ON orders.customer_id = customers.id
#   WHERE orders.total > customers.credit_limit
```

---

## Annotations — Adding Computed Columns

An annotation adds a virtual column to each row in the queryset. It's computed by the database, not Python.

```python
from django.db.models import Count, Sum, Avg, Max, Min, Value, CharField
```

### Basic Aggregation Annotations

```python
# Count how many orders each customer has
customers = Customer.objects.annotate(
    order_count=Count("orders"),             # "orders" is the related_name on the FK
)
for c in customers:
    print(c.name, c.order_count)             # order_count is now a real attribute on each customer
# → SELECT customers.*, COUNT(orders.id) AS order_count
#   FROM customers LEFT JOIN orders ON customers.id = orders.customer_id
#   GROUP BY customers.id

# Sum and average
customers = Customer.objects.annotate(
    total_spent=Sum("orders__total"),         # traverse the FK
    avg_order=Avg("orders__total"),
)

# You can filter ON annotations:
big_spenders = Customer.objects.annotate(
    total_spent=Sum("orders__total"),
).filter(total_spent__gt=10000)              # HAVING total_spent > 10000
```

That last example shows something important: when you `.filter()` on an annotation, Django generates a `HAVING` clause (not `WHERE`), because the annotation is computed after grouping.

### `aggregate()` vs `annotate()` — The Difference

```python
# aggregate — collapses the entire queryset into a single dict
Order.objects.aggregate(
    total_revenue=Sum("total"),
    biggest_order=Max("total"),
)
# → {"total_revenue": Decimal("52300.00"), "biggest_order": Decimal("4200.00")}
# One row, no queryset returned.

# annotate — adds a column to EACH row, returns a queryset
Customer.objects.annotate(order_count=Count("orders"))
# → queryset of customers, each with .order_count attribute
```

Think of it this way: `aggregate` answers "what's the total across everything?" while `annotate` answers "what's the count/sum/avg *per row*?"

### Conditional Annotations with Case/When

```python
from django.db.models import Case, When, Value, CharField, IntegerField

orders = Order.objects.annotate(
    size_bucket=Case(
        When(total__gte=1000, then=Value("large")),
        When(total__gte=100, then=Value("medium")),
        default=Value("small"),
        output_field=CharField(),
    )
)
for order in orders:
    print(order.total, order.size_bucket)    # "150.00 medium", "2000.00 large", etc.

# Count by condition — "how many active vs inactive orders per customer"
from django.db.models import Sum

customers = Customer.objects.annotate(
    active_orders=Count("orders", filter=Q(orders__status="active")),
    cancelled_orders=Count("orders", filter=Q(orders__status="cancelled")),
)
# The filter= parameter on aggregation functions is like a conditional COUNT.
# → COUNT(CASE WHEN orders.status = 'active' THEN orders.id END) AS active_orders
```

The `filter=` argument on `Count`, `Sum`, etc. is a Django 2.0+ feature and is cleaner than writing `Case/When` for simple conditions.

### Database Functions

Django provides SQL functions as Python classes:

```python
from django.db.models.functions import (
    # String
    Lower, Upper, Length, Trim, Concat, Substr, Replace,
    # Date/Time
    Now, TruncDate, TruncMonth, TruncYear, ExtractYear, ExtractMonth, ExtractHour,
    # Comparison
    Coalesce, Greatest, Least, NullIf,
    # Type
    Cast,
)

# Coalesce — return the first non-NULL value
Customer.objects.annotate(
    display_name=Coalesce("nickname", "name", Value("Anonymous"))
)
# → COALESCE(nickname, name, 'Anonymous')

# TruncMonth — group orders by month
from django.db.models.functions import TruncMonth
Order.objects.annotate(
    month=TruncMonth("created_at")
).values("month").annotate(
    count=Count("id"),
    revenue=Sum("total"),
).order_by("month")
# → groups by month, gives count and revenue per month

# Concat
Customer.objects.annotate(
    full_name=Concat("first_name", Value(" "), "last_name")
)
```

---

## Subquery and OuterRef — When One Query Depends on Another

Sometimes you need "for each row in the outer query, look up something from another table." That's a correlated subquery.

```python
from django.db.models import Subquery, OuterRef
```

### The Concept

`OuterRef("field")` is like `F("field")`, but it references a field from the **outer** query, not the current one. It's what connects the inner and outer queries.

```python
# "For each customer, find the date of their most recent order"

# Step 1: write the inner query — "most recent order for a given customer"
latest_order_date = (
    Order.objects
    .filter(customer=OuterRef("pk"))            # "where order.customer_id = customer.id"
    .order_by("-created_at")
    .values("created_at")[:1]                   # just the first value (LIMIT 1)
)

# Step 2: attach it to the outer query
customers = Customer.objects.annotate(
    latest_order_date=Subquery(latest_order_date)
)

for c in customers:
    print(c.name, c.latest_order_date)
```

**The SQL this generates:**
```sql
SELECT customers.*,
       (SELECT orders.created_at
        FROM orders
        WHERE orders.customer_id = customers.id
        ORDER BY orders.created_at DESC
        LIMIT 1
       ) AS latest_order_date
FROM customers
```

The subquery runs once per row in the outer query (the DB optimizer may handle this efficiently with indexes).

### Why `.values("field")[:1]`?

A subquery in a SELECT clause must return a single value (one row, one column). `.values("created_at")` picks the column, `[:1]` adds `LIMIT 1`. Without both, Django raises an error.

### Exists — "Does at Least One Row Match?"

```python
from django.db.models import Exists, OuterRef

# "Customers who have at least one active order"
has_active_order = Order.objects.filter(
    customer=OuterRef("pk"),
    status="active",
)

customers = Customer.objects.annotate(
    has_active_order=Exists(has_active_order)
).filter(has_active_order=True)
```

`Exists` generates `SELECT EXISTS(SELECT 1 FROM orders WHERE ...)` — the DB stops as soon as it finds one matching row, so it's very efficient. Much better than annotating a count and checking if it's > 0.

### Subquery in `.filter()` — Not Just Annotations

```python
# "Orders whose total is higher than their customer's average order"
avg_for_customer = (
    Order.objects
    .filter(customer=OuterRef("customer"))
    .values("customer")
    .annotate(avg=Avg("total"))
    .values("avg")
)

above_average_orders = Order.objects.filter(total__gt=Subquery(avg_for_customer))
```

---

## Seeing the SQL — Your Debugging Superpower

Whenever you're unsure what SQL a queryset generates, just print it:

```python
qs = Order.objects.filter(customer__name="Alice").select_related("customer")

print(qs.query)
# → SELECT "orders"."id", "orders"."customer_id", "orders"."total", ...
#   FROM "orders"
#   INNER JOIN "customers" ON ("orders"."customer_id" = "customers"."id")
#   WHERE "customers"."name" = 'Alice'
```

For finer detail including timing, install `django-debug-toolbar` or use:

```python
from django.db import connection
# After running some queries:
for query in connection.queries:
    print(query["time"], query["sql"])
```

This requires `DEBUG=True` in settings.

---

## Common Import Cheatsheet

```python
# The model base class and all field types
from django.db import models

# Query construction
from django.db.models import (
    Q,                                          # OR, NOT, complex lookups
    F,                                          # column references
    Value,                                      # literal SQL values
    Count, Sum, Avg, Max, Min,                  # aggregation functions
    Case, When,                                 # conditional expressions
    Subquery, OuterRef, Exists,                 # correlated subqueries
    Prefetch,                                   # custom prefetch (covered in Part 3)
)

# Database functions
from django.db.models.functions import (
    Concat, Lower, Upper, Length, Trim,          # string ops
    Coalesce, Greatest, Least, NullIf,           # null handling / comparison
    Now, TruncDate, TruncMonth, ExtractYear,     # date/time
    Cast,                                        # type casting
)

# Constraints
from django.db.models import UniqueConstraint, CheckConstraint

# Exceptions
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned
from django.db import IntegrityError
```

---

*Next: [Part 3 — Performance, Prefetching & Patterns](./03_performance_and_patterns.md) — the N+1 problem, how prefetching actually generates queries, transactions, signals, and daily patterns.*
