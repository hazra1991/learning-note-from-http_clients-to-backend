# Part 3 — Performance, Prefetching & Patterns

> The N+1 problem, how `select_related` and `prefetch_related` actually generate SQL, how the prefetch cache works and what breaks it, transactions, signals, managers, and the patterns you'll use every day.

---

## The N+1 Problem — The Bug You Don't See Until Production

The N+1 problem is the single most common performance issue in Django applications. It's invisible in development (where N is small) and devastating in production (where N is large).

### What It Looks Like

```python
# Innocent-looking code:
orders = Order.objects.all()        # 1 query: SELECT * FROM orders
for order in orders:
    print(order.customer.name)       # 1 query PER ORDER: SELECT * FROM customers WHERE id = ?
```

If you have 500 orders, this fires **501 queries**. One to get the orders, then one per order to get its customer. That's the "+1" (the initial query) plus "N" (one per result row).

Why does `order.customer` hit the DB? Because when Django loaded the order from the first query, it only loaded the `customer_id` integer. The `Customer` object itself was never fetched. So when you access `order.customer`, Django's descriptor sees "I don't have this object yet" and fires `SELECT * FROM customers WHERE id = 42`.

**The same thing happens with reverse relationships:**

```python
customers = Customer.objects.all()        # 1 query
for customer in customers:
    print(customer.orders.all())           # 1 query PER CUSTOMER
# → 1 + N queries
```

And with **ManyToMany**:

```python
products = Product.objects.all()           # 1 query
for product in products:
    print(product.tags.all())              # 1 query PER PRODUCT (hits the join table + tags table)
# → 1 + N queries
```

---

## `select_related` — Solving N+1 with a SQL JOIN

`select_related` tells Django: "I'm going to access this related object, so fetch it now in the same query using a JOIN."

```python
orders = Order.objects.select_related("customer").all()
```

**The SQL Django generates:**
```sql
SELECT orders.id, orders.customer_id, orders.total, orders.created_at,
       customers.id, customers.name, customers.email, customers.is_active
FROM orders
INNER JOIN customers ON orders.customer_id = customers.id
```

One query. Every `order` object now has `customer` fully loaded as a Python object. `order.customer.name` is just an attribute access — zero DB hits.

### Why It Only Works for ForeignKey and OneToOne

`select_related` uses a SQL JOIN. A JOIN matches each row on the left with matching rows on the right. This works cleanly when the relationship is **to-one**: each order has exactly one customer, so the JOIN produces the same number of rows as the original table.

But reverse ForeignKey is **to-many**: one customer can have many orders. If you tried to JOIN:

```sql
SELECT customers.*, orders.*
FROM customers
JOIN orders ON customers.id = orders.customer_id
```

A customer with 5 orders appears **5 times** in the result. Now your "list of customers" has duplicate customers, your pagination is wrong, your count is wrong. This is why Django doesn't let you `select_related` reverse FKs or M2M — the row multiplication breaks everything.

### Multi-level `select_related`

You can follow FK chains across multiple tables:

```python
# Models:
# LineItem → Order (FK) → Customer (FK) → CustomerProfile (OneToOne)
# LineItem → Product (FK) → Category (FK)

items = LineItem.objects.select_related(
    "order__customer__profile",       # 3 hops via FK/OneToOne
    "product__category",              # 2 hops via FK
)
```

**Generated SQL — a single query with 5 JOINs:**
```sql
SELECT line_items.*, orders.*, customers.*, profiles.*, products.*, categories.*
FROM line_items
INNER JOIN orders ON line_items.order_id = orders.id
INNER JOIN customers ON orders.customer_id = customers.id
LEFT JOIN customer_profiles ON customers.id = customer_profiles.customer_id
INNER JOIN products ON line_items.product_id = products.id
INNER JOIN categories ON products.category_id = categories.id
```

Notice: the profile JOIN is a LEFT JOIN because OneToOne relationships might not have a matching row (a customer might not have a profile). FK JOINs are INNER by default because the FK column is NOT NULL — there must be a matching row.

### When select_related Hurts

More JOINs = wider rows = more data transferred. If you `select_related` a chain of 5 tables but only need data from 2 of them, you're wasting bandwidth. Be specific — only select_related what you'll actually access.

`select_related()` with no arguments follows **all** non-null FK and OneToOne relationships recursively. Never do this in production — it can join your entire schema into one monstrous query.

---

## `prefetch_related` — Solving N+1 with Separate Queries

For reverse ForeignKey and ManyToMany relationships, Django uses a different strategy: run a **separate query** and stitch the results together in Python.

```python
customers = Customer.objects.prefetch_related("orders")
```

**This generates exactly 2 queries:**

```sql
-- Query 1: the main query
SELECT * FROM customers

-- Query 2: all orders for ALL those customers in one shot
SELECT * FROM orders WHERE customer_id IN (1, 2, 3, 4, 5, ...)
```

Django collects all customer IDs from Query 1, puts them in an `IN (...)` clause, and fires Query 2. Then it groups the orders by `customer_id` in Python and attaches them to each customer object. After this, `customer.orders.all()` returns a queryset with results already cached — no DB hit.

### How Many Queries Does Prefetch Generate? — Counting Them

Each string in `prefetch_related()` generates one additional query. But chains are walked step by step:

```python
qs = Order.objects.select_related(
    "customer",                                # JOIN — adds 0 extra queries
).prefetch_related(
    "line_items",                              # +1 query: SELECT * FROM line_items WHERE order_id IN (...)
    "line_items__product",                     # +1 query: SELECT * FROM products WHERE id IN (...)
    "line_items__product__tags",               # +2 queries:
                                               #   SELECT * FROM product_tags WHERE product_id IN (...)
                                               #   SELECT * FROM tags WHERE id IN (...)
)
```

**Total query count:**
1. Main query (orders + customer via JOIN) = 1
2. `line_items` = 1
3. `products` for those line items = 1
4. Join table `product_tags` = 1
5. `tags` = 1

**= 5 queries total**, regardless of how many orders, line items, or products exist. Without prefetching, if you had 100 orders with 5 line items each and 3 tags per product, that'd be 1 + 100 + 500 + 1500 = **2101 queries**. Prefetching collapsed it to 5.

### How the Prefetch Cache Works Internally

When `prefetch_related` runs, Django stores the results in a dictionary called `_prefetched_objects_cache` on each parent instance. The key is the lookup name (e.g., `"orders"`). The value is a queryset with `_result_cache` already populated.

```python
customers = Customer.objects.prefetch_related("orders")

for customer in customers:
    # Django checks: does customer._prefetched_objects_cache have key "orders"?
    # YES → return the cached queryset (its _result_cache is already filled)
    # NO DB HIT.
    active = customer.orders.all()

    # Under the hood, .all() does this (simplified):
    #   1. Create a new queryset for orders
    #   2. Check _prefetched_objects_cache for key "orders"
    #   3. Found → return the cached queryset with pre-filled results
    #   4. The queryset's _result_cache is already populated, so iteration is instant
```

### What Breaks the Prefetch Cache

The cache is only used when you call `.all()`. Any method that implies a different query bypasses the cache:

```python
customers = Customer.objects.prefetch_related("orders")

for customer in customers:
    customer.orders.all()                     # ✅ cache hit — no query
    list(customer.orders.all())               # ✅ cache hit — .all() then iterate

    customer.orders.filter(total__gt=100)     # ❌ NEW QUERY — .filter() is not .all()
    customer.orders.count()                   # ❌ NEW QUERY — .count() is a different operation
    customer.orders.order_by("-total")        # ❌ NEW QUERY — .order_by() is not .all()
    customer.orders.values("total")           # ❌ NEW QUERY

    customer.orders.all()[:5]                 # ✅ cache hit — slicing works because
                                              # _result_cache is already populated, so [:5]
                                              # is just a Python list slice, not a SQL LIMIT
```

The rule is simple: `.all()` → cache hit. Anything else → new query. This is because the cache stores the result of the specific query that was prefetched. `.filter(total__gt=100)` is a *different* query — Django can't know if the cached results satisfy it.

---

## The `Prefetch` Object — Full Control Over What Gets Prefetched

When you need to filter, sort, or annotate the prefetched queryset, pass a `Prefetch` object instead of a string.

```python
from django.db.models import Prefetch
```

### Filtering the Prefetched Query

```python
customers = Customer.objects.prefetch_related(
    Prefetch(
        "orders",
        queryset=Order.objects.filter(status="active").order_by("-created_at"),
    )
)

# Now customer.orders.all() returns ONLY active orders, already sorted.
# The prefetch query is:
# SELECT * FROM orders WHERE customer_id IN (...) AND status = 'active' ORDER BY created_at DESC
```

This works — `.all()` still hits the cache. But there's a problem: the code says `.all()` which *looks* like "all orders," but you're actually getting a filtered subset. That's misleading, and it's a bug waiting to happen when another developer (or future you) reads the code and assumes `.all()` means everything.

### `to_attr` — The Clean Solution

`to_attr` stores the prefetched results under a custom attribute name, as a **plain Python list**:

```python
customers = Customer.objects.prefetch_related(
    Prefetch(
        "orders",
        queryset=Order.objects.filter(status="active"),
        to_attr="active_orders",           # stored as a list, not a manager
    )
)

for customer in customers:
    # A plain Python list — not a queryset, not a manager
    for order in customer.active_orders:
        print(order.total)

    # The original manager is UNTOUCHED:
    # customer.orders.all() would fire a NEW query (the prefetch only filled active_orders)
```

**Why `to_attr` is the recommended approach for filtered prefetches:**

1. **No ambiguity.** `customer.active_orders` says exactly what it is. `customer.orders.all()` returning only active orders is lying to the reader.

2. **It's a list.** You literally cannot call `.filter()` on a Python list, so you can't accidentally trigger a new query. With a queryset, calling `.filter()` would bypass the cache silently.

3. **Multiple prefetches on the same relation.** Without `to_attr`, you can't prefetch "active orders" and "cancelled orders" separately — both would try to fill the same `orders` cache. With `to_attr`:

```python
Customer.objects.prefetch_related(
    Prefetch("orders", queryset=Order.objects.filter(status="active"), to_attr="active_orders"),
    Prefetch("orders", queryset=Order.objects.filter(status="cancelled"), to_attr="cancelled_orders"),
)
# customer.active_orders → list
# customer.cancelled_orders → list
# No conflict, no ambiguity.
```

### Prefetching with `select_related` Inside the Prefetch

You can optimize the prefetched queryset itself:

```python
Customer.objects.prefetch_related(
    Prefetch(
        "orders",
        queryset=Order.objects.select_related("shipping_address").filter(status="active"),
        to_attr="active_orders",
    )
)
# The prefetch query now JOINs shipping_address:
# SELECT orders.*, addresses.* FROM orders
# INNER JOIN addresses ON orders.shipping_address_id = addresses.id
# WHERE orders.customer_id IN (...) AND orders.status = 'active'
```

### Nested Prefetch

```python
Customer.objects.prefetch_related(
    Prefetch(
        "orders",
        queryset=Order.objects.prefetch_related(
            Prefetch(
                "line_items",
                queryset=LineItem.objects.select_related("product"),
            )
        ),
        to_attr="recent_orders",
    )
)
# 1 query: customers
# 1 query: orders (with filter) WHERE customer_id IN (...)
# 1 query: line_items WHERE order_id IN (...) — with product JOINed
# = 3 queries total, fully loaded nested structure
```

---

## Combining `select_related` + `prefetch_related` — The Real-World Pattern

In practice, most views need both. Here's a realistic example:

```python
# Models:
# Order → Customer (FK)
# Customer → CustomerProfile (OneToOne)
# Order ← LineItem (reverse FK)
# LineItem → Product (FK)
# Product ↔ Tag (M2M)

qs = Order.objects.select_related(
    "customer",                          # FK forward → JOIN
    "customer__profile",                 # OneToOne → JOIN
).prefetch_related(
    "line_items",                        # reverse FK → separate query
    Prefetch(
        "line_items__product__tags",     # M2M → separate queries
        queryset=Tag.objects.filter(active=True),
        to_attr="active_tags",
    ),
)

# Query breakdown:
# 1. SELECT orders.*, customers.*, profiles.* FROM orders
#    INNER JOIN customers ON ...
#    LEFT JOIN profiles ON ...
# 2. SELECT * FROM line_items WHERE order_id IN (...)
# 3. SELECT * FROM products WHERE id IN (...)
# 4. SELECT * FROM product_tags WHERE product_id IN (...)
#    + SELECT * FROM tags WHERE id IN (...) AND active = TRUE
# = ~5 queries regardless of data volume

for order in qs:
    order.customer.name                       # no query — JOINed
    order.customer.profile.bio                # no query — JOINed
    for item in order.line_items.all():       # no query — prefetched
        item.product.name                     # no query — prefetched (product was fetched in query 3)
        for tag in item.product.active_tags:  # no query — prefetched list
            print(tag.name)
```

---

## Transactions — All-or-Nothing Database Operations

When multiple database changes must succeed or fail together, wrap them in a transaction.

```python
from django.db import transaction
```

### The `atomic` Block

```python
with transaction.atomic():
    order = Order.objects.create(customer=customer, total=0)
    LineItem.objects.create(order=order, product=product, qty=2, price=50)
    LineItem.objects.create(order=order, product=product2, qty=1, price=30)
    order.total = 130
    order.save()
    # If ANY line raises an exception, ALL changes are rolled back.
    # The order and line items either ALL exist or NONE of them do.
```

Without `atomic`, if the second `LineItem.objects.create` fails, you'd have an order with only one line item — an inconsistent state.

### As a Decorator

```python
@transaction.atomic
def create_order(customer, items):
    order = Order.objects.create(customer=customer, total=0)
    total = 0
    for item in items:
        li = LineItem.objects.create(order=order, **item)
        total += li.price * li.qty
    order.total = total
    order.save()
    return order
# If the function raises, everything inside is rolled back.
```

### Savepoints — Partial Rollback

```python
with transaction.atomic():                     # outer transaction
    order = Order.objects.create(total=100)

    try:
        with transaction.atomic():             # savepoint (nested atomic block)
            send_notification(order)            # might fail
            NotificationLog.objects.create(order=order, sent=True)
    except NotificationError:
        pass                                    # savepoint rolled back, but order survives
        # NotificationLog was NOT created, but order still exists

    # Continue — order is committed when the outer block exits
```

### `select_for_update` — Row-Level Locking

Prevents other transactions from modifying these rows until your transaction commits:

```python
with transaction.atomic():
    product = Product.objects.select_for_update().get(id=1)
    # Any other transaction trying to UPDATE or select_for_update on this row
    # will BLOCK until this transaction commits or rolls back.
    product.stock -= 1
    product.save()
```

Common options:
```python
.select_for_update(skip_locked=True)     # skip rows already locked (useful for job queues)
.select_for_update(no_key=True)          # Postgres: allows inserts on rows that reference this one
.select_for_update(of=("self",))         # only lock the main table, not JOINed tables
```

### `on_commit` — Run Code After Successful Commit

```python
with transaction.atomic():
    order = Order.objects.create(total=100)
    transaction.on_commit(lambda: send_order_email(order.id))
    # The email is only sent if the transaction commits successfully.
    # If it rolls back, the on_commit callback is discarded.
```

This is essential for side effects like sending emails, pushing to queues, or calling external APIs. You don't want to send a "your order is confirmed" email if the order's transaction later rolls back.

---

## Managers and Custom QuerySets

The `objects` attribute on your model is a **Manager**. It's the entry point for all database queries. You can customize it.

### Custom QuerySet — Reusable Query Logic

```python
class OrderQuerySet(models.QuerySet):
    def active(self):
        return self.filter(status="active")

    def high_value(self, threshold=500):
        return self.filter(total__gt=threshold)

    def for_customer(self, customer):
        return self.filter(customer=customer)

    def with_item_count(self):
        return self.annotate(item_count=Count("line_items"))

class Order(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name="orders")
    total = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20)

    objects = OrderQuerySet.as_manager()    # replaces the default manager

# Now you chain your custom methods like any built-in method:
Order.objects.active().high_value(1000).with_item_count().order_by("-total")

# They work in subqueries too:
Customer.objects.filter(orders__in=Order.objects.active().high_value())
```

### Custom Manager — For Default Filtering

```python
class ActiveOrderManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(is_deleted=False)

class Order(models.Model):
    is_deleted = models.BooleanField(default=False)
    # ...
    objects = ActiveOrderManager()        # default — always excludes soft-deleted
    all_objects = models.Manager()        # escape hatch — includes everything

# Order.objects.all() → only non-deleted orders
# Order.all_objects.all() → everything, including deleted
```

Be careful with default-filtering managers: they affect admin, related managers, and other code that assumes `.all()` means "everything."

---

## Signals — Reacting to Model Events

Signals let you run code when certain things happen to model instances.

```python
from django.db.models.signals import pre_save, post_save, pre_delete, post_delete
from django.dispatch import receiver

@receiver(post_save, sender=Customer)
def on_customer_created(sender, instance, created, **kwargs):
    """Runs every time a Customer is saved."""
    if created:
        # Brand new customer — create their profile
        CustomerProfile.objects.create(customer=instance)
    else:
        # Existing customer updated
        pass

@receiver(pre_delete, sender=Order)
def on_order_about_to_be_deleted(sender, instance, **kwargs):
    """Runs just before an Order is deleted."""
    log_deletion(instance)
```

### The Critical Limitation

Signals only fire when you work with **individual instances**:

```python
# ✅ Triggers post_save:
order = Order(total=100)
order.save()

# ✅ Triggers post_save (create calls .save() internally):
Order.objects.create(total=100)

# ❌ Does NOT trigger any signal:
Order.objects.filter(status="old").update(status="archived")    # queryset .update()
Order.objects.filter(status="old").delete()                     # queryset .delete()
Order.objects.bulk_create([Order(total=100), Order(total=200)]) # bulk_create
Order.objects.bulk_update(orders, ["total"])                     # bulk_update
```

Queryset-level `.update()` and `.delete()` bypass signals because they operate directly in SQL without loading instances into Python. If you need signals to fire, you must loop and call `.save()` or `.delete()` on each instance individually (which is slower, obviously).

### Where to Put Signal Handlers

In your app's `apps.py`:

```python
# myapp/apps.py
from django.apps import AppConfig

class MyappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "myapp"

    def ready(self):
        import myapp.signals   # noqa — importing triggers the @receiver decorators
```

And put your signal handlers in `myapp/signals.py`.

---

## Practical Patterns

### Soft Delete

```python
class SoftDeleteModel(models.Model):
    is_deleted = models.BooleanField(default=False, db_index=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True

    def soft_delete(self):
        from django.utils import timezone
        self.is_deleted = True
        self.deleted_at = timezone.now()
        self.save(update_fields=["is_deleted", "deleted_at"])
        # update_fields tells .save() to only UPDATE these 2 columns,
        # not all columns — more efficient and avoids overwriting concurrent changes
```

### `update_fields` — Surgical Updates

```python
order.status = "shipped"
order.save(update_fields=["status"])
# → UPDATE orders SET status = 'shipped' WHERE id = 42
# Instead of: UPDATE orders SET status=..., total=..., created_at=..., ... WHERE id = 42
# Faster, and doesn't overwrite changes made by another process to other fields.
```

### Efficient Bulk Operations

```python
# Bulk create — single INSERT for many rows
Order.objects.bulk_create(
    [Order(customer=c, total=100) for c in customers],
    batch_size=500,      # sends 500 rows per INSERT statement
)

# Bulk update — UPDATE in batches
orders = list(Order.objects.filter(status="pending"))
for order in orders:
    order.status = "expired"
Order.objects.bulk_update(orders, ["status"], batch_size=500)

# Mass update without loading objects — single UPDATE query
Order.objects.filter(
    status="pending",
    created_at__lt=cutoff_date,
).update(status="expired")
# Fastest — one SQL UPDATE, no Python objects, no signals.
```

### `get_or_create` and `update_or_create`

```python
# Get an existing object, or create it if it doesn't exist
customer, was_created = Customer.objects.get_or_create(
    email="alice@example.com",                    # lookup fields
    defaults={"name": "Alice", "is_active": True} # only used if creating
)
# was_created is True if a new object was created, False if an existing one was returned

# Update an existing object, or create it if it doesn't exist
customer, was_created = Customer.objects.update_or_create(
    email="alice@example.com",                    # lookup fields
    defaults={"name": "Alice Updated"}            # these fields are SET whether creating or updating
)
```

### Existence Checks — The Right Way

```python
# ❌ Slow — loads all objects, counts in Python:
if len(Order.objects.filter(customer=c)) > 0:
    ...

# ❌ Better but still does COUNT(*):
if Order.objects.filter(customer=c).count() > 0:
    ...

# ✅ Best — SELECT 1 LIMIT 1, stops immediately:
if Order.objects.filter(customer=c).exists():
    ...
```

### The "Get One Related Object" Pattern

```python
# Scenario: for each customer, show their most recent order

# Approach 1: Prefetch everything, pick first in Python
customers = Customer.objects.prefetch_related(
    Prefetch(
        "orders",
        queryset=Order.objects.order_by("-created_at"),
        to_attr="sorted_orders",
    )
)
for c in customers:
    latest = c.sorted_orders[0] if c.sorted_orders else None
# Downside: prefetches ALL orders for each customer just to use one

# Approach 2: Subquery annotation — single query, scalar value
from django.db.models import Subquery, OuterRef
latest_total = (
    Order.objects
    .filter(customer=OuterRef("pk"))
    .order_by("-created_at")
    .values("total")[:1]
)
customers = Customer.objects.annotate(latest_order_total=Subquery(latest_total))
# Now c.latest_order_total is available — but it's just the value, not the full order object

# Approach 3: Subquery + to get a full object, use a two-step
latest_order_ids = (
    Order.objects
    .filter(customer=OuterRef("pk"))
    .order_by("-created_at")
    .values("id")[:1]
)
customers = Customer.objects.annotate(latest_order_id=Subquery(latest_order_ids))
# Then bulk-fetch orders by those IDs if you need the full objects
```

---

## Quick Decision Flowchart

```
You need data from a related model. Which tool do you reach for?
│
├─ FK forward (order.customer) or OneToOne?
│  └─ select_related("customer")
│     → SQL JOIN, one query, fully loaded object
│
├─ FK reverse (customer.orders) or ManyToMany?
│  └─ prefetch_related("orders")
│     → separate IN query, stitched in Python
│     │
│     ├─ Need to filter/sort the prefetched set?
│     │  └─ Prefetch("orders", queryset=..., to_attr="active_orders")
│     │
│     └─ Plain .all() access is enough?
│        └─ prefetch_related("orders") with a string is fine
│
├─ Just need a single value (count, max, latest date)?
│  └─ annotate with Count/Subquery — no prefetch needed
│
└─ Accessing data in a loop without any optimization?
   └─ You have an N+1 problem. Go back to the top.
```

---

## Debugging Checklist

1. **Print the SQL:** `print(qs.query)` — see what Django is actually generating.
2. **Count queries:** Use `django-debug-toolbar` or `from django.db import connection; print(len(connection.queries))`.
3. **`assertNumQueries` in tests:**
   ```python
   with self.assertNumQueries(3):
       list(Customer.objects.prefetch_related("orders", "orders__line_items"))
   ```
4. **Check for N+1 in templates:** If a template loops over objects and accesses related data, make sure the view's queryset has the right `select_related`/`prefetch_related`.
5. **`EXPLAIN` via raw SQL:** `cursor.execute("EXPLAIN ANALYZE " + str(qs.query))` to see the query plan.

---

*These three files together cover the Django ORM patterns you'll use in 90% of production code. When in doubt: define relationships correctly (Part 1), build queries with the right tools (Part 2), and make sure you're not doing N+1 (Part 3).*
